// src/constants/index.ts
export const THEMES = ['Enhance','Reduce','Eliminate'];
export const DEPTS = ['Production','Quality','Safety','Maintenance'];
